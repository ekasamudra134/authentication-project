module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "test_yatech",
  };